# CNBOX language payload builder
# Fixed source clients (project owner paths):
#   NA   = E:\World_of_Tanks_NA
#   ASIA = E:\World_of_Tanks_ASIA
#   CN   = E:\World_of_Tanks_CN
# Output:
#   E:\CNBOX_LANGUAGE_PACK_<WoTVersion>.zip
#
# This script READS the three clients and only writes the staging folder/output ZIP on E:\.

$ErrorActionPreference = "Stop"
$NA   = "E:\World_of_Tanks_NA"
$ASIA = "E:\World_of_Tanks_ASIA"
$CN   = "E:\World_of_Tanks_CN"
$STAGE = "E:\CNBOX_LANGUAGE_PACK_BUILD"

function Get-VersionInfo([string]$Root) {
    $vf = Join-Path $Root "version.xml"
    if (!(Test-Path $vf)) { throw "version.xml not found: $vf" }
    $raw = Get-Content $vf -Raw
    $version = if ($raw -match "<version>\s*v?\.?\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)") { $Matches[1] } else { "" }
    $realm = if ($raw -match "<realm>\s*([^<]+?)\s*</realm>") { $Matches[1].Trim() } else { "" }
    [pscustomobject]@{ Root=$Root; Version=$version; Realm=$realm; Raw=$raw }
}

$naInfo = Get-VersionInfo $NA
$asInfo = Get-VersionInfo $ASIA
$cnInfo = Get-VersionInfo $CN

if ($naInfo.Realm -ne "NA")   { throw "NA realm check failed: $($naInfo.Realm)" }
if ($asInfo.Realm -ne "ASIA") { throw "ASIA realm check failed: $($asInfo.Realm)" }
if ($cnInfo.Realm -ne "CN")   { throw "CN realm check failed: $($cnInfo.Realm)" }
if ($naInfo.Version -ne $asInfo.Version -or $naInfo.Version -ne $cnInfo.Version) {
    throw "WoT versions do not match: NA=$($naInfo.Version) ASIA=$($asInfo.Version) CN=$($cnInfo.Version)"
}

$OUT = "E:\CNBOX_LANGUAGE_PACK_$($naInfo.Version).zip"

if (Test-Path $STAGE) { Remove-Item $STAGE -Recurse -Force }
New-Item "$STAGE\asia\res\text\lc_messages" -ItemType Directory -Force | Out-Null
New-Item "$STAGE\asia\res\gui\flash" -ItemType Directory -Force | Out-Null
New-Item "$STAGE\cn\res\text\lc_messages" -ItemType Directory -Force | Out-Null

$asiaLc = "$ASIA\res\text\lc_messages"
$cnLc   = "$CN\res\text\lc_messages"

$asiaMo = @(Get-ChildItem $asiaLc -Filter *.mo -File -Recurse)
$cnVehicles = @(Get-ChildItem $cnLc -Filter "*_vehicles.mo" -File)

foreach ($f in $asiaMo) {
    $rel = $f.FullName.Substring($asiaLc.Length).TrimStart("\")
    $dest = Join-Path "$STAGE\asia\res\text\lc_messages" $rel
    New-Item (Split-Path $dest -Parent) -ItemType Directory -Force | Out-Null
    Copy-Item $f.FullName $dest -Force
}

Copy-Item "$ASIA\res\gui\flash\fontconfig.xml" "$STAGE\asia\res\gui\flash\fontconfig.xml" -Force

foreach ($f in $cnVehicles) {
    Copy-Item $f.FullName "$STAGE\cn\res\text\lc_messages\$($f.Name)" -Force
}

$manifest = [ordered]@{
    schemaVersion = 1
    packVersion = "1.0"
    wotVersion = $naInfo.Version
    source = "ASIA Simplified Chinese UI + CN vehicle-name layer"
    asiaMoCount = $asiaMo.Count
    cnVehicleMoCount = $cnVehicles.Count
    createdAtUtc = [DateTime]::UtcNow.ToString("o")
}
$manifest | ConvertTo-Json | Set-Content "$STAGE\language_pack_manifest.json" -Encoding UTF8

if (Test-Path $OUT) { Remove-Item $OUT -Force }
Compress-Archive -Path "$STAGE\*" -DestinationPath $OUT -CompressionLevel Optimal
Remove-Item $STAGE -Recurse -Force

$hash = (Get-FileHash $OUT -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ""
Write-Host "DONE" -ForegroundColor Green
Write-Host $OUT -ForegroundColor Yellow
Write-Host "SHA256: $hash"
Write-Host "ASIA .mo: $($asiaMo.Count)"
Write-Host "CN *_vehicles.mo: $($cnVehicles.Count)"
