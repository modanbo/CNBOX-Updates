# CN BOX 2.4.0.1 AUTO / rebased from locked R34 semantics
# Event-driven one-shot PlayersPanel transition: PREBATTLE/Large -> BATTLE/Short.
# No polling. Manual mode changes remain available after the automatic transition.

import BigWorld
from PlayerEvents import g_playerEvents
from constants import ARENA_PERIOD
from xvm_actionscript import as_xfw_cmd
from xvm_main.logger import log, warn

_CMD = 'PLAYERS_PANEL_ALT_MODE'
_SHORT_STATE = 1
_HANDLER_SLOT = '_CNBOX_STEP02_AUTO_MODE_PERIOD_HANDLER'
_fired = False


def _cnbox_onArenaPeriodChange(period, periodEndTime, periodLength, periodAdditionalInfo):
    global _fired
    if period == ARENA_PERIOD.BATTLE:
        if not _fired:
            _fired = True
            log('PREBATTLE->BATTLE: request PlayersPanel SHORT (state=1)', '[CNBOX-AUTO] ')
            as_xfw_cmd(_CMD, _SHORT_STATE)
    else:
        # Arm for the next BATTLE edge. This does not change the current panel mode.
        _fired = False


# Idempotent across XVM py_macro reloads: remove the previously registered function
# stored on the persistent BigWorld module before registering this freshly executed one.
_old = getattr(BigWorld, _HANDLER_SLOT, None)
if _old is not None:
    try:
        g_playerEvents.onArenaPeriodChange -= _old
    except Exception as ex:
        warn('[CNBOX-AUTO] stale period handler detach failed: %s' % ex)

g_playerEvents.onArenaPeriodChange += _cnbox_onArenaPeriodChange
setattr(BigWorld, _HANDLER_SLOT, _cnbox_onArenaPeriodChange)
log('arena-period handler registered; target state=SHORT(1)', '[CNBOX-AUTO] ')
