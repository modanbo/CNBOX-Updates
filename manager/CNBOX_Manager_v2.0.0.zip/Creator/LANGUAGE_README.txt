CNBOX Manager v1.0.3 — 中文语言切换

界面新增三个操作：
1. 汉化（中文坦克名称）
   - 使用 ASIA 官方简体中文界面。
   - 再覆盖 CN 的 *_vehicles.mo，因此坦克名称采用国服中文名称。

2. 汉化（英文坦克名称）
   - 使用 ASIA 官方简体中文界面。
   - 不覆盖 CN 车辆语言文件，因此坦克名称保持 ASIA/WG 英文名称。

3. 恢复原始语言
   - 第一次执行汉化前，Manager 自动备份当前 NA 的：
     res\text\lc_messages\*.mo
     res\gui\flash\fontconfig.xml
   - 备份按“客户端 + WoT 版本”隔离保存。
   - Manager 状态区会显示实际备份路径。
   - 不跨 WoT 版本恢复。

语言功能只针对 World of Tanks NA 客户端，不修改：
- version.xml
- realm / 服务器配置
- WorldOfTanks.exe
- mods / res_mods
- Aslain
- CNBOX 插件文件

发布结构：
- 私有源码：NA-BOX / work/cnbox-manager-v1 / 02_TOOLS/CNBOX_Manager
- 私有发布记录：NA-BOX / 06_RELEASES
- 公共语言包：CNBOX-Updates / language
- 二进制归档：Google Drive / CNBOX_RELEASE_STAGING / CNBOX_LANGUAGE_PACKS

当前固定开发源客户端：
NA   = E:\World_of_Tanks_NA
ASIA = E:\World_of_Tanks_ASIA
CN   = E:\World_of_Tanks_CN


v1.0.8 备份位置更新
- 原始 NA 语言备份不再默认单独放在 AppData。
- 新备份使用 Manager 界面中“回滚备份位置”的同一个保存地址。
- 实际目录：
  <回滚备份位置>\CNBOX_LANGUAGE_BACKUPS\<客户端ID>\<版本_代次>\original_language.zip
- 同一客户端仍只保留当前代次一份原始语言备份。
- 如果旧版 Manager 已经在 %LOCALAPPDATA%\CNBOX_Manager\language_backups 建立了当前代次备份，
  v1.0.8 在需要时会自动迁移到新的回滚备份地址。


v1.1.1 中文坦克名称落盘验证
- “中文坦克名称”不再只依赖内存中的命中计数判断成功。
- 每个写入后的 *_vehicles.mo 会立即重新打开，并逐项核对准备写入的 CN 车辆名称。
- 任意一项落盘值不一致时，本次汉化判定失败，并自动恢复当前代次原始 NA 语言。
- 状态区显示：名称匹配数、落盘验证数、车辆语言文件验证数、含中文字符的已验证名称数。
- 该验证只证明语言文件写入正确；若全部 PASS 但游戏仍显示英文，应继续检查 WoT/CNBOX/XVM 最终显示 owner。


v1.1.1 游戏运行状态 / XVM 车辆名缓存保护
- 当前 XVM 13.1.0.0089 会在启动初始化时从 WoT vehicle descriptor 读取 localized vehicle strings，并建立车辆名缓存。
- 因此游戏运行中禁止执行“汉化（中文坦克名称）”“汉化（英文坦克名称）”或“恢复原始语言”。
- Manager 检测到所选 NA 的 WorldOfTanks.exe 正在运行时直接停止，不改写语言文件。
- 汉化成功且落盘验证 PASS 后再启动游戏，使 WoT/XVM 从新语言文件重新读取车辆名称。
- 中文坦克名称模式还要求落盘验证结果至少包含一个中文字符；否则判失败并自动恢复原始语言。
