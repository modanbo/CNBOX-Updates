/**
 * Polish translation file.
 */
{
  "locale": {
    // Common
    "Warning": "Uwaga",
    "Error": "Błąd",
    "Information": "Informacja",
    "OK": "OK",
    "Cancel": "Anuluj",
    "Save": "Zapisz",
    "Remove": "Usuń",
    "Yes": "Tak",
    "No": "Nie",
    "Not available short": "n/d",
    "from": "od",
    "m": "m",

    // Ping & Online
    "Initialization": "Inicjalizacja",
    "Ping": "Ping",
    "Online": "Online",

    // HitLog
    "shot": "strzał",
    "fire": "pożar",
    "ramming": "taranowanie",
    "world_collision": "spadanie",
    "death_zone": "strefa śmierci",
    "pillbox": "Bunkrów {0}",

    "Hits": "Trafienia",
    "Total": "Razem",
    "Last": "Ostatnie",

    // Capture
    "enemyBaseCapture": "Baza{0} zajmowana przez sojuszników!",
    "enemyBaseCaptured": "Baza{0} zajęta przez sojuszników!",
    "allyBaseCapture": "Baza{0} zajmowana przez przeciwników!",
    "allyBaseCaptured": "Baza{0} zajęta przez przeciwników!",
    "baseCaptureBlocked": "Zajmowanie bazy zablokowane.",

    // Battle interface labels
    "avgDamage": "Śr. obrażenia",
    "mainGun": "Duży kaliber",

    // Devices
    "engine": "silnik",
    "ammo_bay": "amunicja",
    "fuel_tank": "zbiornik paliwa",
    "radio": "radio",
    "left_track": "lewa gąsienica",
    "right_track": "prawa gąsienica",
    "gun": "działo",
    "turret_rotator": "mechanizm obrotu wieży",
    "surveying_device": "dalmierz",

    // Tankmen
    "commander": "dowódca",
    "driver": "kierowca",
    "radioman": "radiooperator",
    "gunner": "celowniczy",
    "loader": "ładowniczy",

    // DamageLog
    "sec": "sek",
    "drowning": "utonięcie",
    "forsaken": "zapomniany",
    "fireMsg": "OGIEŃ",
    // Shell kind, macro {{type-shell}}
    "armor_piercing": "AP",
    "high_explosive": "HE",
    "armor_piercing_cr": "APCR",
    "armor_piercing_he": "HESH",
    "hollow_charge": "HC ",
    "flame": "FM",
    // Text at hits no damage (ricochet, no penetration, no damage), macro {{dmg}}
    "intermediate_ricochet": "rykoszet",
    "final_ricochet": "rykoszet",
    "armor_not_pierced": "odbity",
    "armor_pierced_no_damage": "zablokowane",
    // Name part of vehicle, macro {{comp-name}}
    "turret": "wieża",
    "hull": "kadłub",
    "chassis": "podwozie",
    "wheel": "koło",

    // BattleResults
    "Hit percent": "Procent trafień",
    "Damage (assisted / own)": "Obrażenia (asysta / własne)",
    "BR_xpCrew": "<font face='xvm'>&#x6B;</font>",

    // TeamRenderers
    "Friend": "Przyjaciel",
    "Ignored": "Ignorowany",
    "unknown": "nieznany",
    "Fights": "Walki",
    "Wins": "Wygrane",
    "Data was updated at": "Dane zaktualizowano",
    "Load statistics": "Załaduj statystyki",

    // Profile
    "General stats": "Ogólne statystyki",
    "Summary": "Podsumowanie",
    "Avg level": "Śr. poziom",
    "WTR": "WTR",
    "WN8": "WN8",
    "EFF": "EFF",
    "WGR": "WGR",
    "updated": "zaktualizowano",
    "toWithSpaces": " do ",
    "avg": "średnie",
    "top": "najlepsze",
    "draws": "remisy",
    "Maximum damage": "Maksymalne obrażenia",
    "Specific damage (Avg dmg / HP)": "Specyficzne obrażenia (Śr. obrażenia / punkty życia) ",
    "Capture points": "Punkty zajmowania",
    "Defence points": "Punkty obrony",
    "Filter": "Filtr",
    "Extra data (WoT 0.8.8+)": "Dodatkowe dane (WoT 0.8.8+)",
    "Average battle time": "Śr. czas bitwy",
    "Average battle time per day": "Śr. czas bitwy na dzień",
    "Battles after 0.8.8": "Bitew po 0.8.8",
    "Average experience": "Śr. doświadczenie",
    "Average experience without premium": "Śr. doświadczenie bez premium",
    "Average distance driven per battle": "Śr. dystans pokonany na bitwę",
    "Average woodcuts per battle": "Śr. ściętych drzew na bitwę",
    "Average damage assisted": "Śr. obrażenia (asysta)",
    "    by tracking": "    przez uszkodzenie gąsienic",
    "    by spotting": "    przez spotowanie",
    "Average HE shells fired (splash)": "Śr. wystrzelonych pocisków HE (obszarowe)",
    "Average HE shells received (splash)": "Śr. otrzymanych strzałów HE (obszarowe)",
    "Average penetrations per battle": "Śr. trafień penetrujących na bitwę",
    "Average hits received": "Śr. otrzymanych trafień",
    "Average penetrations received": "Śr. otrzymanych trafień penetrujących",
    "Average ricochets received": "Śr. otrzymanych rykoszetów",
    "better than": "lepsze niż",

    // Crew
    "PutOwnCrew": "Obsadź załogę (własna)",
    "PutBestCrew": "Obsadź załogę (najlepsza)",
    "PutClassCrew": "Obsadź członka załogi tej samej klasy",
    "PutPreviousCrew": "Przywróć poprzednią załogę",
    "DropAllCrew": "Wyślij załogę do koszar",
    "noSkills": "Brak umiejętności",

    // Vehicle Params
    "gun_reload_time/actual": "Bieżący czas przeładowania",
    "view_range/base": "bazowy",
    "view_range/actual": "bieżący",
    "view_range/stereoscope": "z lornetą",
    "radio_range/base": "bazowy",
    "radio_range/actual": "bieżący",
    "lowAmmo": "Mało amunicji",
    "shootingRadius": "Zasięg ostrzału",
    "flameMaxDistance": "Promień miotacza ognia",
    "pitchLimitsSide": "Kąt wychyłu (bok)",
    "pitchLimitsRear": "Kąt wychyłu (tył)",
    "terrainResistance": "Opory dla gruntu (twardy/średni/miękki)",
    "gravity": "Grawitacja",
    "shellSpeed": "Prędkość pocisku",
    "general": "Ogólne",
    "armor": "Opancerzenie",
    "firepower": "Siła ognia",
    "mobility": "Mobilność",
    "crew": "Załoga",
    "(m/sec)": "(m/sek)",
    "(sec)": "(sek)",
    "(m)": "(m)",

    // Nation
    "ussr": "ZSSR",
    "germany": "Niemcy",
    "usa": "USA",
    "france": "Francja",
    "uk": "Wielka Brytania",
    "china": "Chiny",
    "japan": "Japonia",
    "czech": "Czechy",
    "poland": "Polska",
    "sweden": "Szwecja",
    "italy": "Włochy",

    // Vehicle type
    "HT": "HT",
    "MT": "MT",
    "LT": "LT",
    "TD": "TD",
    "SPG": "SPG",

    // VehicleMarkersManager
    "blownUp": "Wysadzony!",

    // Check version
    // XVM 5.3.4 (4321)
    "ver/currentVersion": "XVM {0} ({1})",
    "ver/newVersion": "Dostępna aktualizacja: <a href='#XVM_SITE_DL#'><font color='#00FF00'>XVM {0}</font></a>\n{1}",
    "xvmsvc/not_connected": "<font color='#FFFF00'>Brak połączenia z serwerem XVM</font>",

    // Token
    "token/services_unavailable": "Usługi sieciowe niedostępne.&nbsp;&nbsp;<a href='#XVM_SITE_UNAVAILABLE#'><font size='11'>więcej informacji</font></a>",
    "token/services_inactive": "Usługi sieciowe nieaktywne.&nbsp;&nbsp;<br><a href='#XVM_SITE_INACTIVE#'><font size='12'>Aktywuj</font></a>&nbsp;&nbsp;&nbsp;<a href='#XVM_CHECK_ACTIVATION#'><font size='12'>Sprawdź aktywację</font></a>",
    "token/services_not_activated": "Nie udało się aktywować usług sieciowych. Przed sprawdzeniem, aktywuj usługi na swoim koncie w witrynie XVM.<br><a href='#XVM_SITE_INACTIVE#'><font size='12'>Aktywuj</font></a>&nbsp;&nbsp;&nbsp;<a href='#XVM_CHECK_ACTIVATION#'><font size='12'>Sprawdź aktywację</font></a>",
    "token/blocked": "Stan: <font color='#FF0000'>Zablokowany</font>&nbsp;&nbsp;<a href='#XVM_SITE_BLOCKED#'><font size='11'>więcej informacji</font></a>",
    "token/active": "Stan: <font color='#00FF00'>Aktywny</font>",
    "token/time_left": "Pozostało: <font color='#EEEEEE'>{0}d. {1}g. {2}m.</font>",
    "token/time_left_warn": "<tab/><font color='#EEEEEE'>{0}d. {1}g. {2}m.</font>\n<tab/><a href='#XVM_SITE#'>Przedłuż</a>",
    "token/unknown_status": "Nieznany stan",

    // Stats link
    "stats_link/svcmsg": "<a href='event:https://stats.modxvm.com/en/stats/players/{0}#svcmsg'><font color='#E2D2A2'>Twoje statystyki na stronie XVM</font></a>",
    "stats_link/profile_self": "<a href='event:https://stats.modxvm.com/en/stats/players/{0}#profile'><font color='#E2D2A2'><u>Twoje statystyki na stronie XVM</u></font></a>",
    "stats_link/profile": "<a href='event:https://stats.modxvm.com/en/stats/players/{0}#profile'><font color='#E2D2A2'><u>Statystyki graczy na stronie XVM</u></font></a>",

    // Lobby
    "lobby/header/gold_locked_tooltip": "Używanie złota zablokowane",
    "lobby/header/gold_unlocked_tooltip": "Używanie złota odblokowane",
    "lobby/header/freexp_locked_tooltip": "Używanie wolnego XP zablokowane",
    "lobby/header/freexp_unlocked_tooltip": "Używanie wolnego XP odblokowane",
    "lobby/header/crystal_locked_tooltip": "Używanie złota zablokowane",
    "lobby/header/crystal_unlocked_tooltip": "Używanie złota odblokowane",

    "lobby/crew/enable_prev_crew": "Automatycznie przywróć załogę",
    "lobby/crew/enable_prev_crew_tooltip": "<b><font color='#FDF4CE'>{{l10n:lobby/crew/enable_prev_crew}}</font></b>\nAutomatycznie przywraca załogę która walczyła\nw tym pojeździe w poprzedniej bitwie.",

    // Profile
    "profile/xvm_xte_tooltip": "<b><font color='#FDF4CE' size='16'>хте</font></b>\nEfektywności na danym czołgu\nWięcej informacji w <font color='#FDF4CE'>https://modxvm.com/ratings/</font>",
    "profile/xvm_xte_extended_tooltip": "<textformat tabstops='[20, 85, 140]'>{{l10n:profile/xvm_xte_tooltip}}\n\nWartości referencyjne:\n\t\tObrażenia\tfrags\n\tAktualnie:\t<font color='#FDF4CE' size='14'>{0}</font>\t<font color='#FDF4CE' size='14'>{1}</font>\n\tŚrednio:\t<font color='#FDF4CE' size='14'>{2}</font>\t<font color='#FDF4CE' size='14'>{3}</font>\n\tMaksymalnie:\t<font color='#FDF4CE' size='14'>{4}</font>\t<font color='#FDF4CE' size='14'>{5}</font>",

    // Carousel
    "Premium": "Premium",
    "PremiumTooltipHeader": "Pojazdy premium",
    "PremiumTooltipBody": "Pokaż pojazdy premium.",
    "Special": "Nagroda",
    "SpecialTooltipHeader": "Pojazdy z nagród.",
    "SpecialTooltipBody": "Pokaż pojazdy z nagród.",
    "Normal": "Normalny",
    "NormalTooltipHeader": "Pojazd",
    "NormalTooltipBody": "Pokaż zwykłe pojazdy (bez premium).",
    "NonElite": "Nieelitarny",
    "NonEliteTooltipHeader": "Nieelitarne pojazdy",
    "NonEliteTooltipBody": "Pokaż pojazdy bez wybadanych wszystkich modułów i drzewek technologicznych.",
    "CompleteCrew": "Pełna załoga",
    "CompleteCrewTooltipHeader": "Pełna załoga",
    "CompleteCrewTooltipBody": "Pokaż pojazdy z pełną załogą.",
    "TrainingCrew": "Załoga do wytrenowania",
    "TrainingCrewTooltipHeader": "Załoga do wytrenowania",
    "TrainingCrewTooltipBody": "Pokaż pojazdy, którch załoga ma mniej niż 100% poziomu wytrenowania.",
    "NoMaster": "Bez \"Asa\"",
    "NoMasterTooltipHeader": "Bez \"Asa\"",
    "NoMasterTooltipBody": "Pokaż pojazdy bez odznaki \"As Pancerny\".",
    "ReserveFilter": "Rezerwowe",
    "ReserveFilterTooltipHeader": "Rezerwowe",
    "ReserveFilterTooltipBody": "Pokaż pojazdy rezerwowe.",
    "check_reserve_menu": "Ustaw jako rezerwowy",
    "uncheck_reserve_menu": "Odznacz etykietę rezerwowy",
    "reserve_confirm_title": "Ukryj czołg",
    "reserve_confirm_message": "Czy na pewno chcesz oznaczyć czołg jako rezerwowy? Będzie dostępny za pośrednictwem filtrów w karuzeli.",
    "Used slots": "Użytych miejsc",

    // Comments
    "Network services unavailable": "Usługi sieciowe niedostępne",
    "Error loading comments": "Błąd ładowania komentarzy",
    "Error saving comments": "Błąd zapisywania komentarzy",
    "Comments disabled": "Komentarze wyłączone",
    "Edit data": "Edytuj dane",
    "Nick": "Nazwa",
    "Group": "Grupa",
    "Comment": "Komentarz",

    // Vehicle status
    "Destroyed": "Zniszczony",
    "No data": "Brak danych",
    "Not ready": "Niegotowy",

    // Quests
    "Hide with honors": "Ukryj wyróżnione",
    "Started": "Rozpoczęte",
    "Incomplete": "Niekompletne",

    // Config loading
    "XVM config reloaded": "Konfiguracja XVM została przeładowana",
    "Config file xvm.xc was not found, using the built-in config": "Nie znaleziono pliku xvm.xc, załadowano domyślną konfigurację XVM",
    "Error loading XVM config": "Błąd ładowania konfiguracji XVM"
  }
}
