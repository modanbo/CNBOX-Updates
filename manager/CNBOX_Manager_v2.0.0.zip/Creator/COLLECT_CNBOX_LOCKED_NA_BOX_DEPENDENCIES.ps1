$ErrorActionPreference = "Stop"

$ROOT  = "E:\World_of_Tanks_NA"
$STAGE = "E:\CNBOX_LOCKED_NA_BOX_DEPENDENCIES_BUILD"
$OUT   = "E:\CNBOX_LOCKED_NA_BOX_DEPENDENCIES.zip"

if (!(Test-Path "$ROOT\version.xml")) { throw "找不到 NA 客户端：$ROOT" }

$raw = Get-Content "$ROOT\version.xml" -Raw
$m = [regex]::Match($raw, '([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)')
if (!$m.Success) { throw "无法识别 WoT 四段版本号" }
$VER = $m.Groups[1].Value

if (Test-Path $STAGE) { Remove-Item $STAGE -Recurse -Force }
New-Item $STAGE -ItemType Directory -Force | Out-Null

$seen = New-Object System.Collections.Generic.HashSet[string] ([StringComparer]::OrdinalIgnoreCase)
$records = New-Object System.Collections.Generic.List[object]

function Copy-Rel([string]$Rel, [string]$Category) {
    $relNorm = $Rel.Replace('/','\').TrimStart('\')
    $src = Join-Path $ROOT $relNorm
    if (!(Test-Path -LiteralPath $src -PathType Leaf)) { return }

    $key = $relNorm.Replace('\','/')
    if (!$seen.Add($key)) { return }

    $dst = Join-Path $STAGE $relNorm
    New-Item (Split-Path $dst -Parent) -ItemType Directory -Force | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force

    $fi = Get-Item -LiteralPath $src
    $records.Add([pscustomobject]@{
        Path=$key
        Category=$Category
        Size=$fi.Length
        SHA256=(Get-FileHash $src -Algorithm SHA256).Hash.ToLowerInvariant()
    })
}

function Copy-Tree([string]$RelDir, [string]$Category, [scriptblock]$Include=$null) {
    $dir = Join-Path $ROOT $RelDir
    if (!(Test-Path $dir -PathType Container)) { return }

    Get-ChildItem $dir -File -Recurse | ForEach-Object {
        if ($_.FullName -match '[\\/]__pycache__[\\/]') { return }
        if ($Include -and !(& $Include $_.FullName)) { return }
        $rel = $_.FullName.Substring($ROOT.Length).TrimStart('\')
        Copy-Rel $rel $Category
    }
}

function Copy-Glob([string]$RelDir, [string]$Pattern, [string]$Category) {
    $dir = Join-Path $ROOT $RelDir
    if (!(Test-Path $dir -PathType Container)) { return }
    Get-ChildItem $dir -File -Filter $Pattern -ErrorAction SilentlyContinue | ForEach-Object {
        $rel = $_.FullName.Substring($ROOT.Length).TrimStart('\')
        Copy-Rel $rel $Category
    }
}

Copy-Rel "version.xml" "client_metadata"
Copy-Rel "mods\configs\AslainsModpackVersion.json" "aslain_metadata"
Copy-Rel "mods\configs\AslainModpackVersion.json" "aslain_metadata"

Copy-Rel "res_mods\configs\xvm\xvm.xc" "xvm_selector"
Copy-Tree "res_mods\configs\xvm\Aslain" "aslain_xvm_profile"
Copy-Tree "res_mods\configs\xvm\py_macro" "xvm_py_macro" {
    param($p)
    return !$p.EndsWith(".pyc", [StringComparison]::OrdinalIgnoreCase)
}
Copy-Tree "res_mods\mods\shared_resources\xvm" "xvm_shared_runtime" {
    param($p)
    return ($p.Replace('\','/') -notmatch '/shared_resources/xvm/doc/')
}

Copy-Glob "mods\$VER" "com.modxvm.xvm_*.wotmod" "xvm_core_wotmod"
Copy-Glob "mods\$VER\com.modxvm.xfw" "com.modxvm.xfw.crashfix_*.wotmod" "xvm_crashfix"
Copy-Glob "mods\$VER\net.openwg" "net.openwg.common_*.wotmod" "openwg_common"
Copy-Glob "mods\$VER\net.openwg" "net.openwg.fix.battleresultscache_*.wotmod" "openwg_fix"
Copy-Glob "mods\$VER\net.openwg" "net.openwg.fix.battleresultsreplays_*.wotmod" "openwg_fix"
Copy-Glob "res_mods\$VER\audioww" "xvm*.bnk" "xvm_audio"
Copy-Rel "res_mods\$VER\scripts\client\gui\mods\__init__.pyc" "xvm_client_runtime"

Copy-Rel "CNBOX_UNIFIED_OWNER.json" "cnbox_owner_metadata"
Copy-Rel "res_mods\$VER\gui\flash\battleVehicleMarkersApp.swf" "cnbox_owner"
Copy-Glob "res_mods\$VER\gui\flash\atlases" "cnboxPlayersPanel*" "cnbox_owner"
Copy-Tree "res_mods\$VER\gui\maps\icons\vehicle\contour\cnbox_overhead_jx" "cnbox_owner"
Copy-Rel "res_mods\$VER\scripts\client\gui\mods\mod_cnbox_eff_bridge.pyc" "cnbox_owner"

$records | Sort-Object Path | Export-Csv "$STAGE\CNBOX_DEPENDENCY_MANIFEST.csv" -NoTypeInformation -Encoding UTF8

@"
CNBOX LOCKED NA - COMPLETE BOX DEPENDENCY COLLECTION
WoT: $VER
Client: $ROOT

Included:
- complete Aslain XVM profile used by CNBOX
- complete XVM py_macro runtime source (excluding generated cache)
- XVM shared runtime resources/l10n (excluding documentation)
- XVM/OpenWG runtime WOTMOD dependencies
- XVM audio banks
- XVM client loader
- CNBOX locked owner files
- version / Aslain version metadata

Excluded:
- unrelated Aslain plugins outside the CNBOX/XVM dependency scope
- screenshots
- unrelated garage/skin/sound/UI mods
- XVM documentation files
"@ | Set-Content "$STAGE\README.txt" -Encoding UTF8

if (Test-Path $OUT) { Remove-Item $OUT -Force }
Compress-Archive -Path "$STAGE\*" -DestinationPath $OUT -CompressionLevel Optimal
Remove-Item $STAGE -Recurse -Force

Write-Host ""
Write-Host "DONE" -ForegroundColor Green
Write-Host $OUT -ForegroundColor Yellow
Write-Host "WoT: $VER"
Write-Host "Dependency files: $($records.Count)"
