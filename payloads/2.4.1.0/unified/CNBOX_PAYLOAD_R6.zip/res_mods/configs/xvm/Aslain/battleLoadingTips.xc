/**
 * Parameters of the alternative view of the Battle Loading screen.
 * Параметры альтернативного представления экрана загрузки боя.
 */
{
  "templates": {
    // Clan icon definition.
    // Шаблон иконки клана.
    "clanIcon": {
      "enabled": true,
      "x": -200, "y": 0, "width": 22, "height": 22, "align": "center", "alpha": 90,
      "src": "{{clanicon}}"
    }
  },
  "battleLoadingTips": {
    // Format of clock on the Battle Loading Screen.
    // Формат часов на экране загрузки боя.
    // http://php.net/date
    "clockFormat": "H:i:s",
    // true - disable platoon/rank icons. This blank space can house, for example, clan logos.
    // true - убрать отображение иконки взвода/ранга. На пустое поле можно вывести, например, иконку клана.
    "removeSquadIcon": false,
    // true - disable badge icons.
    // true - убрать отображение иконки нашивки.
    "removeRankBadgeIcon": false,
    // true - disable alpha/beta testers icons.
    // true - убрать отображение иконки альфа/бета тестеров.
    "removeTesterIcon": false,
    // true - hide elite levels.
    // true - убрать отображение уровней элитности.
    "removePrestigeLevel": false,
    // Opacity percentage of vehicle icon. 0 - transparent ... 100 - opaque.
    // Прозрачность в процентах иконки танка. 0 - прозрачные, 100 - не прозрачные.
    "vehicleIconAlpha": 100,
    // true - disable vehicle level indicator.
    // true - убрать отображение уровня танка.
    "removeVehicleLevel": false,
    // true - disable vehicle type icon. This space will be used for formatted vehicle field.
    // true - убрать отображение типа танка. Пустое место будет использовано под форматируемое поле.
    "removeVehicleTypeIcon": true,
    // Show border for name field (useful for config tuning).
    // Показывать рамку для поля имени игрока (полезно для настройки конфига).
    "nameFieldShowBorder": false,
    // Show border for vehicle field (useful for config tuning).
    // Показывать рамку для поля имени танка (полезно для настройки конфига).
    "vehicleFieldShowBorder": false,
    // X offset for allies squad icons.
    // Смещение по оси X значка взвода союзников.
    "squadIconOffsetXLeft": -120,
    // X offset for enemies squad icons.
    // Смещение по оси X значка взвода противников.
    "squadIconOffsetXRight": -120,
    // X offset for allies player names field.
    // Смещение по оси X поля ника союзников.
    "nameFieldOffsetXLeft": -180,
    // Width delta for allies player names field.
    // Изменение ширины поля ника союзников.
    "nameFieldWidthDeltaLeft": 120,
    // X offset for enemies player names field.
    // Смещение по оси X поля ника противников.
    "nameFieldOffsetXRight": -185,
    // Width delta for enemies player names field.
    // Изменение ширины поля ника противников.
    "nameFieldWidthDeltaRight": 120,
    // X offset for allies vehicle names field.
    // Смещение по оси X поля названия танка союзников.
    "vehicleFieldOffsetXLeft": -40,
    // Width delta for allies vehicle names field.
    // Изменение ширины поля названия танка союзников.
    "vehicleFieldWidthDeltaLeft": 120,
    // X offset for enemies vehicle names field.
    // Смещение по оси X поля названия танка противников.
    "vehicleFieldOffsetXRight": -40,
    // Width delta for enemies vehicle names field.
    // Изменение ширины поля названия танка противников.
    "vehicleFieldWidthDeltaRight": 120,
    // X offset for allies vehicle icons.
    // Смещение по оси X иконки танка союзников.
    "vehicleIconOffsetXLeft": 0,
    // X offset for enemies vehicle icons.
    // Смещение по оси X иконки танка противников.
    "vehicleIconOffsetXRight": 0,
    // false - disable highlight of icons during battle start depends on ready state.
    // false - отключить затемнение иконки не загрузившегося игрока.
    "darkenNotReadyIcon": true,
    // Display format for the left panel (macros allowed, see macros.txt).
    // Формат отображения для левой панели (допускаются макроподстановки, см. macros_ru.txt).
    "formatLeftNick": "<img src='xvm://res/icons/flags/default.png' width='16' height='13' vspace='-2'> <img src='xvm://res/icons/xvm/none.png'> {{name%.15s~..}} <font alpha='#A0'>{{clan}}</font>",
    // Display format for the right panel (macros allowed, see macros.txt).
    // Формат отображения для правой панели (допускаются макроподстановки, см. macros_ru.txt).
    "formatRightNick": "<font alpha='#A0'>{{clan}}</font> {{name%.15s~..}} <img src='xvm://res/icons/xvm/none.png'> <img src='xvm://res/icons/flags/default.png' width='16' height='13' vspace='-2'>",
    // Display format for the left panel (macros allowed, see macros.txt).
    // Формат отображения для левой панели (допускаются макроподстановки, см. macros_ru.txt).
    "formatLeftVehicle": "{{vehicle}}<font face='mono' size='{{xvm-stat?13|0}}'> <font color='{{c:r}}'>{{r}}</font></font>",
    // Display format for the right panel (macros allowed, see macros.txt).
    // Формат отображения для правой панели (допускаются макроподстановки, см. macros_ru.txt).
    "formatRightVehicle": "<font face='mono' size='{{xvm-stat?13|0}}'><font color='{{c:r}}'>{{r}}</font> </font>{{vehicle}}",
    // Extra fields. Fields are placed one above the other.
    // Дополнительные поля. Поля располагаются друг над другом.
    // Set of formats for left panel (extended format supported, see extra-field.txt)
    // Набор форматов для левой панели (поддерживается расширенный формат, см. extra-field_ru.txt)
    "extraFieldsLeft": [
      //${"templates.clanIcon"},
      {}
    ],
    // Set of formats for right panel (extended format supported, see extra-field.txt).
    // Набор форматов для правой панели (поддерживается расширенный формат, см. extra-field_ru.txt).
    "extraFieldsRight": [
      //${"templates.clanIcon"},
      {}
    ]
  }
}
