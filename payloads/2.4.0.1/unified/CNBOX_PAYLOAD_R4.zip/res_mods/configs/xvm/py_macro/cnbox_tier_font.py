# -*- coding: utf-8 -*-
# CNBOX player-panel tier font isolation.
# Do not alter WG/XVM global $FieldFont/$TitleFont/$TextFont aliases.

try:
    import openwg_fonts
    openwg_fonts.add_alias(u"CNBOXTierFont", u"ZurichCondMono")
except Exception:
    # XVM/OpenWG load diagnostics will expose a missing font API; do not change
    # unrelated UI as a fallback.
    pass
