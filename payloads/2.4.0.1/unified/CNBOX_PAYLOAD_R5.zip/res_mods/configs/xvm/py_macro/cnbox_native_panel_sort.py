# CN BOX 2.4.0.1 S1 / rebased from locked R34 semantics
# Bottom-owner patch: change only VehicleInfoSortKey._cmp, which is consumed by
# TeamsSortedIDsComposer for both leftItemsIDs and rightItemsIDs.
#
# Native death flow (verified from current NA/CN scripts.pkg):
# VehicleArenaInfoVO.updateVehicleStatus -> INVALIDATE_OP.SORTING ->
# BattleStatisticsDataController.invalidateVehicleStatus -> addSortIDs ->
# AllyItemsCollection/EnemyItemsCollection -> VehicleInfoSortKey._cmp.

from gui.battle_control.arena_info import vos_collections
from xvm_main.logger import log


_CLASS_PRIORITY = {
    'heavyTank': 0,
    'mediumTank': 1,
    'AT-SPG': 2,
    'lightTank': 3,
    'SPG': 4
}
_ORIGINAL_SLOT = '_cnbox_2400_original_cmp'


def _cmp_value(a, b):
    return (a > b) - (a < b)


def _cnbox_native_panel_cmp(self, other):
    left = self.vInfoVO
    right = other.vInfoVO

    result = _cmp_value(left.team, right.team)
    if result:
        return result

    # Preserve the native bottom-layer death key: survivors sort before
    # destroyed vehicles.  On every alive-state transition the game marks the
    # vehicle update as SORTING and republishes both teams' sorted ID arrays.
    result = _cmp_value(right.isAlive(), left.isAlive())
    if result:
        return result

    left_type = left.vehicleType
    right_type = right.vehicleType
    result = _cmp_value(
        _CLASS_PRIORITY.get(left_type.classTag, 5),
        _CLASS_PRIORITY.get(right_type.classTag, 5)
    )
    if result:
        return result

    result = _cmp_value(right_type.level, left_type.level)
    if result:
        return result

    # Python's stable sort preserves native input order for exact ties.  Player
    # name and localized vehicle name remain deliberately excluded.
    return 0


_sort_key = vos_collections.VehicleInfoSortKey
if not hasattr(_sort_key, _ORIGINAL_SLOT):
    setattr(_sort_key, _ORIGINAL_SLOT, _sort_key._cmp)
_sort_key._cmp = _cnbox_native_panel_cmp
log(
    'bottom comparator installed: alive first; HT>MT>TD>LT>SPG; tier desc; stable ties',
    '[CNBOX-SORT-S1] '
)
