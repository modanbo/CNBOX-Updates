/**
 * List of battle interface labels.
 * Список текстовых полей боевого интерфейса.
 */
{
  "labels": {
    // Referenced labels:
    // * every custom field can be separate enabled or disabled by "enabled" switch in their settings.
    // * extended format supported, see extra-field.txt
    // Подключенные текстовые поля:
    // * кастомные поля можно отдельно отключать и включать с помощью "enabled" в их настройках.
    // * поддерживается расширенный формат, см. extra-field_ru.txt
    "formats": [
      ${"battleLabelsTemplates.xc":"def.hitLogBackground"},
      ${"battleLabelsTemplates.xc":"def.hitLogBody"},
      ${"battleLabelsTemplates.xc":"def.hitLogHeader"},
      ${"battleLabelsTemplates.xc":"def.winChance"},
      ${"battleLabelsTemplates.xc":"def.teamRating"},
      ${"battleLabelsTemplates.xc":"def.totalEfficiency"},
      ${"battleLabelsTemplates.xc":"def.speed"},
      ${"battleLabelsTemplates.xc":"def.totalHP"},
      ${"battleLabelsTemplates.xc":"def.avgDamage"},
      ${"battleLabelsTemplates.xc":"def.mainGun"},
      ${"battleLabelsTemplates.xc":"def.damageLogBackground"},
      ${"battleLabelsTemplates.xc":"def.damageLog"},
      ${"battleLabelsTemplates.xc":"def.lastHit"},
      ${"battleLabelsTemplates.xc":"def.fire"},
      {}
    ]
  }
}
