/**
 * Text substitutions. DEFAULT XVM
 * Текстовые подстановки.
 */
{
  "texts": {
    // Text for {{vtype}} macro.
    // Текст для макроса {{vtype}}.
    "vtype": {
      // Text for light tanks / Текст для легких танков.
      "LT":  "{{l10n:LT}}",
      // Text for medium tanks / Текст для средних танков.
      "MT":  "{{l10n:MT}}",
      // Text for heavy tanks / Текст для тяжелых танков.
      "HT":  "{{l10n:HT}}",
      // Text for arty / Текст для арты.
      "SPG": "{{l10n:SPG}}",
      // Text for tank destroyers / Текст для ПТ.
      "TD":  "{{l10n:TD}}"
    },
    // Text for {{marksOnGun}}, {{v.marksOnGun}} macros.
    // Текст для макросов {{marksOnGun}}, {{v.marksOnGun}}.
    "marksOnGun": {
      "_0": "0",
      "_1": "1",
      "_2": "2",
      "_3": "3"
    },
    // Text for {{spotted}} macro.
    // Текст для макроса {{spotted}}.
    "spotted": {
      "neverSeen": "<img src='cfg://Aslain/icons/cnbox_lighten.png' width='17' height='15'>",
      "lost": "",
      "spotted": "",
      "dead": "",
      "neverSeen_arty": "<img src='cfg://Aslain/icons/cnbox_lighten.png' width='17' height='15'>",
      "lost_arty": "",
      "spotted_arty": "",
      "dead_arty": ""
    },
    // Text for {{xvm-user}} macro.
    // Текст для макроса {{xvm-user}}.
    "xvmuser": {
      // XVM with enabled statistics.
      // XVM со включенной статистикой.
      "on": "on",
      // XVM with disabled statistics.
      // XVM со выключенной статистикой.
      "off": "off",
      // Without XVM.
      // Без XVM.
      "none": "none"
    },
    // Text for {{battletype}} macro.
    // Текст для макроса {{battletype}}.
    "battletype": {
      // Unknown battle.
      // Неизвестный бой.
      "unknown": "",
      // Random battle.
      // Случайный бой.
      "regular": "",
      // Team training.
      // Тренировочный бой.
      "training": "training",
      // Tournament.
      // Турнир.
      "tournament": "tournament",
      // Clan wars.
      // Клановый бой.
      "clan": "clan",
      // Team battles.
      // Командный бой.
      "cybersport": "cybersport",
      // Special game mode (racing, football and other).
      // Бой спецрежима (гонки, футбол и т.п.).
      "event_battles": "",
      // Global map (GM).
      // Глобальная карта (ГК).
      "global_map": "global_map",
      // Regular tournament (event) GM.
      // Регулярный турнир (ивент) ГК.
      "tournament_regular": "tournament_regular",
      // Periodic Tournament (event) GM.
      // Периодический турнир (ивент) ГК.
      "tournament_clan": "tournament_clan",
      // Steel Hunt.
      // Стальная охота.
      "fallout_classic": "",
      // Domination.
      // Превосходство.
      "fallout_multiteam": "",
      // Strongholds, skirmish.
      // Укрепрайон, вылазка.
      "sortie_2": "sortie_2",
      // Strongholds, advance.
      // Укрепрайон, наступление.
      "fort_battle_2": "fort_battle_2",
      // Ranked battle.
      // Ранговый бой.
      "ranked": "",
      // Grand battles.
      // Генеральное сражение.
      "epic_random": "",
      // Grand battles (training).
      // Генеральное сражение (тренировка).
      "epic_random_training": "",
      // Special game mode (new)(racing, football and other).
      // Бой спецрежима (новый)(гонки, футбол и т.п.).
      "event_battles_2": "",
      // Frontline.
      // Линия фронта.
      "epic_battle": "",
      // Frontline (training).
      // Линия фронта (тренировка).
      "epic_battle_training": "",
      // Steel Hunter (solo).
      // Стальной охотник (соло).
      "battle_royale_solo": "",
      // Steel Hunter (squad).
      // Стальной охотник (взвод).
      "battle_royale_squad": "",
      // Tournament (event).
      // Турнир (ивент).
      "tournament_event": "",
      // ?.
      // ?.
      "event_random": "",
      // «Team Clash».
      // «Битва блогеров».
      "bob": "",
      // Steel Hunter (solo, training).
      // Стальной охотник (соло, тренировка).
      "battle_royale_training_solo": "",
      // Steel Hunter (squad, training).
      // Стальной охотник (взвод, тренировка).
      "battle_royale_training_squad": "",
      // «Brawl» mode.
      // Режим «Схватка».
      "weekend_brawl": "",
      // «Recon Mission» mode.
      // Режим «Разведка боем».
      "mapbox": "",
      // «Topography» mode.
      // Режим «Топография».
      "maps_training": ""
    },
    // Text for {{topclan}} macro.
    // Текст для макроса {{topclan}}.
    "topclan": {
      "top": "&#x72;",
      "persist": "&#x73;",
      "regular": ""
    }
  }
}
