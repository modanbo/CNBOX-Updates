/**
 * Parameters of the Players Panels ("ears").
 * Параметры панелей игроков ("ушей").
 */
{
  // Definitions (extended format supported, see extra-field.txt).
  // Шаблоны (поддерживается расширенный формат, см. extra-field_ru.txt).
  "def": {
    // Enemy spotted status marker.
    // Маркер статуса засвета противника.
    "enemySpottedMarker": {
      // R14 frozen #10 coordinate correction: exact yellow triangle; current-owner rebase preserves old JX-left-20 / y=5 geometry.
      "enabled": true,
      "alpha": 100,
      "x": 90,
      "y": 5,
      "width": 20,
      "height": 18,
      "align": "center",
      "bindToIcon": true,
      "format": "{{spotted}}",
      "shadow": { "enabled": false }
    },
    // XMQP service marker definition.
    // Шаблон маркера сервиса XMQP.
    "xmqpServiceMarker": {
      "enabled": true,
      "x": 88, "y": -2, "align": "center", "bindToIcon": true,
      "textFormat": {
        "font": "xvm",
        "size": 24
      },
      "format": "<font color='{{x-spotted?#FFBB00|#D9D9D9}}'>{{alive?{{x-enabled?&#x70;}}}}</font>",
      "shadow": {}
    },
    // Clan icon.
    // Иконка клана.
    "clanIcon": {
      "enabled": true,
      "x": 65, "y": 6, "width": 16, "height": 16, "align": "center", "alpha": 90, "bindToIcon": true,
      "src": "{{clanicon}}"
      //"format": "<img src='{{clanicon}}' width='16' height='16'>"
    },
    // XVM user marker.
    // Маркер пользователя XVM.
    "xvmUserMarker": {
      "enabled": false,
      "x": 10, "y": 5, "bindToIcon": true,
      "src": "xvm://res/icons/xvm/xvm-user-{{xvm-user|none}}.png"
    },
    // CN BOX X3: jx is framework-only; live client tier/name centered inside frame. Visible: LEFT EFF | [TIER | VEHICLE], RIGHT [VEHICLE | TIER] | EFF.
    "cnboxTierLeft": {
      "enabled": true, "x": 2, "y": -3.0, "width": 18, "height": 18, "bindToIcon": true, "layer": "top",
      "align": "left", "valign": "top",
      "textFormat": { "font": "mono", "size": 12, "color": "0xFFFFFF", "align": "center", "valign": "center" },
      "format": "{{level}}", "shadow": {}
    },
    "cnboxTierRight": {
      "enabled": true, "x": 21, "y": -3.0, "width": 18, "height": 18, "bindToIcon": true, "layer": "top",
      "align": "left", "valign": "top",
      "textFormat": { "font": "mono", "size": 12, "color": "0xFFFFFF", "align": "center", "valign": "center" },
      "format": "{{level}}", "shadow": {}
    },
    "cnboxNameLeft": {
      "enabled": true, "x": 23, "y": 4, "width": 55, "height": 18, "bindToIcon": true, "layer": "top",
      "align": "left", "valign": "top",
      "textFormat": { "font": "$FieldFont", "size": 10, "color": "0xFFFFFF", "align": "center", "valign": "center" },
      "format": "<font size='{{py:cnbox.verifiedVehicleNameSize('{{vehiclename}}','{{vehicle}}')}}' color='{{py:cnbox.vehicleNameColor('{{vehiclename}}')}}'>{{py:cnbox.verifiedVehicleName('{{vehiclename}}','{{vehicle}}')}}</font>", "shadow": {}
    },
    "cnboxNameRight": {
      "enabled": true, "x": 79, "y": 4, "width": 55, "height": 18, "bindToIcon": true, "layer": "top",
      "align": "left", "valign": "top",
      "textFormat": { "font": "$FieldFont", "size": 10, "color": "0xFFFFFF", "align": "center", "valign": "center" },
      "format": "<font size='{{py:cnbox.verifiedVehicleNameSize('{{vehiclename}}','{{vehicle}}')}}' color='{{py:cnbox.vehicleNameColor('{{vehiclename}}')}}'>{{py:cnbox.verifiedVehicleName('{{vehiclename}}','{{vehicle}}')}}</font>", "shadow": {}
    },
    // HP bar background.
    // Подложка индикатора HP.
    "hpBarBg": { "hotKeyCode": 56, "onHold": "true", "visibleOnHotKey": true, "x": 96, "y": 6, "width": 72, "bindToIcon": true, "height": 14, "bgColor": "0x000000", "alpha": "{{alive?35|0}}" },
    // HP bar.
    // Индикатор HP.
    "hpBar": { "hotKeyCode": 56, "onHold": "true", "visibleOnHotKey": true, "x": 97, "y": 7, "bindToIcon": true, "width": "{{hp-ratio:70}}", "height": 12, "bgColor": "{{player?#FFDD33|{{c:system}}}}", "alpha": "{{alive?50|0}}" },
    // Remaining HP.
    // Оставшиеся HP.
    "hp": {
      "hotKeyCode": 56, "onHold": "true", "visibleOnHotKey": true, "bindToIcon": true, "alpha": "{{alive?100|0}}",
      "x": 96, "width": 72, "y": 4,
      "textFormat": { "font": "$FieldFont", "size": 11, "color": "0xD9D9D9", "bold": "true", "align": "center" },
      "format": "<font alpha='{{alive?{{ready?#FF|#80}}|#80}}'>{{alive?{{hp|{{hp-max}}}}|{{l10n:Destroyed}}}}</font>",
      "shadow": { "enabled": true, "color": "0x000000", "alpha": 100, "blur": 4, "strength": 1, "distance": 0, "angle": 0 }
    }
  },
  // Parameters of the Players Panels ("ears").
  // Параметры панелей игроков ("ушей").
  "playersPanel": {
    // false - disable.
    // false - отключить.
    "enabled": true,
    // Opacity percentage of the background panels. 0 - transparent, 100 - opaque.
    // Прозрачность в процентах подложки ушей. 0 - прозрачная, 100 - не прозрачная.
    "alpha": 60,
    // Opacity percentage of icons in the panels. 0 - transparent ... 100 - opaque.
    // Прозрачность в процентах иконок в ушах. 0 - прозрачные, 100 - не прозрачные.
    "iconAlpha": 100,
    // true - disable background of the selected player.
    // true - убрать подложку выбранного игрока.
    "removeSelectedBackground": false,
    // true - remove the Players Panel mode switcher (buttons for changing size).
    // true - убрать переключатель режимов ушей мышкой.
    "removePanelsModeSwitcher": false,
    // true - remove the number of hit points (HP) vehicle.
    // true - убрать количество очков прочности (HP) техники.
    "removeHealthPoints": true,
    // Start panels mode. Possible values: "none", "short", "medium", "medium2", "large".
    // Начальный режим ушей. Возможные значения: "none", "short", "medium", "medium2", "large".
    "startMode": "large",
    // Alternative panels mode. Possible values: null, "none", "short", "medium", "medium2", "large".
    // Альтернативный режим ушей. Возможные значения: null, "none", "short", "medium", "medium2", "large".
    "altMode": null,
    // Options for the "none" panels - empty panels.
    // Режим ушей "none" - пустые уши.
    "none": {
      "enabled": true,
      "expandAreaWidth": 230,
      "layout": "vertical",
      "fixedPosition": false,
      "inviteIndicatorAlpha": 100,
      "inviteIndicatorX": 0,
      "inviteIndicatorY": 0,
        "leftPanel": {
          "x": 0,
          "y": 65,
          "width": 350,
          "height": 25,
          "formats": []
        },
        "rightPanel": {
          "x": 0,
          "y": 65,
          "width": 350,
          "height": 25,
          "formats": []
        }
    },
    // Options for the "short" panels - panels with frags and vehicle icon.
    // Режим ушей "short" - короткие уши (фраги и иконка танка).
    "short": {
      "enabled": true,
      "standardFields": [ "frags" ],
      "expandAreaWidth": 230,
      "removeSquadIcon": false,
      "squadIconAlpha": 100,
      "vehicleIconOffsetXLeft": 74,
      "vehicleIconOffsetXRight": 77,
      "vehicleLevelOffsetXLeft": 0,
      "vehicleLevelOffsetXRight": 0,
      "vehicleLevelAlpha": 0,
      "fragsOffsetXLeft": 0,
      "fragsOffsetXRight": 0,
      "fragsWidth": 24,
      "fragsFormatLeft": "{{frags}}",
      "fragsFormatRight": "{{frags}}",
      "fragsShadowLeft": null,
      "fragsShadowRight": null,
      "nickOffsetXLeft": 0,
      "nickOffsetXRight": 0,
      "nickMinWidth": 46,
      "nickMaxWidth": 158,
      "nickFormatLeft": "{{name%.15s~..}}<font alpha='#A0'>{{clan}}</font>{{anonym?<img src='img://gui/maps/icons/library/icon_eye.png' width='16' height='13'>}}",
      "nickFormatRight": "<font alpha='#A0'>{{clan}}</font>{{name%.15s~..}}",
      "nickShadowLeft": null,
      "nickShadowRight": null,
      "prestigeOffsetXLeft": 0,
      "prestigeOffsetXRight": 0,
      "vehicleOffsetXLeft": 0,
      "vehicleOffsetXRight": 0,
      "vehicleWidth": 105,
      "vehicleFormatLeft": "{{vehicle}}",
      "vehicleFormatRight": "{{vehicle}}",
      "vehicleShadowLeft": null,
      "vehicleShadowRight": null,
      "fixedPosition": false,
      "extraFieldsLeft": [
        ${"def.cnboxTierLeft"},
        ${"def.cnboxNameLeft"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        //${"def.xmqpServiceMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
        //3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "60", "alpha": "{{alive? 20|0}}"},
        //3{"x": 0, "y":  19 , "bgColor": ${"def.c1"}, "height":  5 , "width": "{{hp-ratio:60}}", "alpha": "{{alive? 30|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerLeft"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealt"},
        {}
      ],
      "extraFieldsRight": [
        ${"def.cnboxNameRight"},
        ${"def.cnboxTierRight"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        ${"def.enemySpottedMarker"},
		//${"def.BotMarker"},
        //3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "60", "alpha": "{{alive? 20|0}}"},
        //3{"x": 0, "y":  19 , "bgColor": ${"def.c2"}, "height":  5 , "width": "{{hp-ratio:60}}", "alpha": "{{alive? 50|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerRight"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealt"},
        {}
      ]
    },
    // Options for the "medium" panels - the first of the medium panels.
    // Режим ушей "medium" - первые средние уши в игре.
    "medium": {
      "enabled": true,
      "standardFields": [ "frags",  "nick" ],
      "expandAreaWidth": 230,
      "removeSquadIcon": false,
      "squadIconAlpha": 100,
      "vehicleIconOffsetXLeft": 74,
      "vehicleIconOffsetXRight": 77,
      "vehicleLevelOffsetXLeft": 0,
      "vehicleLevelOffsetXRight": 0,
      "vehicleLevelAlpha": 0,
      "fragsOffsetXLeft": 0,
      "fragsOffsetXRight": 0,
      "fragsWidth": 24,
      "fragsFormatLeft": "{{frags}}",
      "fragsFormatRight": "{{frags}}",
      "fragsShadowLeft": null,
      "fragsShadowRight": null,
      "nickOffsetXLeft": 0,
      "nickOffsetXRight": 0,
      "nickMinWidth": 46,
      "nickMaxWidth": 59,
      "nickFormatLeft": "{{nick%.{{anonym?7|9}}s~..}}{{anonym? <font face='xvm' size='13'>&#x11E;</font>}}",
      "nickFormatRight": "{{nick%.9s~..}}",
      "nickShadowLeft": null,
      "nickShadowRight": null,
      "vehicleOffsetXLeft": 0,
      "vehicleOffsetXRight": 0,
      "vehicleWidth": 105,
      "vehicleFormatLeft": "{{vehicle}}",
      "vehicleFormatRight": "{{vehicle}}",
      "vehicleShadowLeft": null,
      "vehicleShadowRight": null,
      "fixedPosition": false,
      "extraFieldsLeft": [
        ${"def.cnboxTierLeft"},
        ${"def.cnboxNameLeft"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        //${"def.xmqpServiceMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
        //3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "118", "alpha": "{{alive? 20|0}}"},
        //3{"x": 0, "y":  19 , "bgColor": ${"def.c1"}, "height":  5 , "width": "{{hp-ratio:118}}", "alpha": "{{alive? 30|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerLeft"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealt"},
        {}
      ],
      "extraFieldsRight": [
        ${"def.cnboxNameRight"},
        ${"def.cnboxTierRight"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        ${"def.enemySpottedMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
        //3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "121", "alpha": "{{alive? 20|0}}"},
        //3{"x": 0, "y":  19 , "bgColor": ${"def.c2"}, "height":  5 , "width": "{{hp-ratio:118}}", "alpha": "{{alive? 50|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerRight"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealt"},
        {}
      ]
    },
    // Options for the "medium2" panels - the second of the medium panels.
    // Режим ушей "medium2" - вторые средние уши в игре.
    "medium2": {
      "enabled": true,
      "standardFields": [ "frags", "vehicle" ],
      "expandAreaWidth": 230,
      "removeSquadIcon": false,
      "squadIconAlpha": 100,
      "vehicleIconOffsetXLeft": 74,
      "vehicleIconOffsetXRight": 77,
      "vehicleLevelOffsetXLeft": 0,
      "vehicleLevelOffsetXRight": 0,
      "vehicleLevelAlpha": 0,
      "fragsOffsetXLeft": 0,
      "fragsOffsetXRight": 0,
      "fragsWidth": 24,
      "fragsFormatLeft": "{{frags}}",
      "fragsFormatRight": "{{frags}}",
      "fragsShadowLeft": null,
      "fragsShadowRight": null,
      "nickOffsetXLeft": 0,
      "nickOffsetXRight": 0,
      "nickMinWidth": 65,
      "nickMaxWidth": 65,
      "nickFormatLeft": "{{vehicle}}",
      "nickFormatRight": "{{vehicle}}",
      "nickShadowLeft": null,
      "nickShadowRight": null,
      "prestigeOffsetXLeft": 26,
      "prestigeOffsetXRight": 0,
      "vehicleOffsetXLeft": 0,
      "vehicleOffsetXRight": 0,
      "vehicleWidth": 105,
      "vehicleFormatLeft": "{{vehicle}}",
      "vehicleFormatRight": "{{vehicle}}",
      "vehicleShadowLeft": null,
      "vehicleShadowRight": null,
      "fixedPosition": false,
      "extraFieldsLeft": [
        ${"def.cnboxTierLeft"},
        ${"def.cnboxNameLeft"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        //${"def.xmqpServiceMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
        //3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "164", "alpha": "{{alive? 20|0}}"},
        //3{"x": 0, "y":  19 , "bgColor": ${"def.c1"}, "height":  5 , "width": "{{hp-ratio:164}}", "alpha": "{{alive? 30|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerLeft"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealt"},
        {}
      ],
      "extraFieldsRight": [
        ${"def.cnboxNameRight"},
        ${"def.cnboxTierRight"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        ${"def.enemySpottedMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
        //3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "166", "alpha": "{{alive? 20|0}}"},
        //3{"x": 0, "y":  19 , "bgColor": ${"def.c2"}, "height":  5 , "width": "{{hp-ratio:166}}", "alpha": "{{alive? 50|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerRight"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealt"},
        {}
      ]
    },
    // Options for the "large" panels - the widest panels.
    // Режим ушей "large" - широкие уши в игре.
    "large": {
      "enabled": true,
      "standardFields": [ "frags", "badge", "nick", "vehicle" ],
      "removeSquadIcon": false,
      "squadIconAlpha": 100,
      "vehicleIconOffsetXLeft": 74,
      "vehicleIconOffsetXRight": 77,
      "vehicleLevelOffsetXLeft": 0,
      "vehicleLevelOffsetXRight": 0,
      "vehicleLevelAlpha": 0,
      "fragsOffsetXLeft": 0,
      "fragsOffsetXRight": 0,
      "fragsWidth": 24,
      "fragsFormatLeft": "{{frags}}",
      "fragsFormatRight": "{{frags}}",
      "fragsShadowLeft": null,
      "fragsShadowRight": null,
      "badgeOffsetXLeft": 0,
      "badgeOffsetXRight": 0,
      "badgeWidth": 24,
      "badgeAlpha": "{{alive?100|70}}",
      "nickOffsetXLeft": 0,
      "nickOffsetXRight": 0,
      "nickMinWidth": 46,
      "nickMaxWidth": 158,
      "nickFormatLeft": "{{name%.15s~..}}",
      "nickFormatRight": "{{name%.15s~..}}",
      "nickShadowLeft": null,
      "nickShadowRight": null,
      "prestigeOffsetXLeft": 26,
      "vehicleOffsetXLeft": 0,
      "vehicleOffsetXRight": 0,
      "vehicleWidth": 72,
      "vehicleFormatLeft": "{{vehicle}}",
      "vehicleFormatRight": "{{vehicle}}",
      "vehicleShadowLeft": null,
      "vehicleShadowRight": null,
      "fixedPosition": false,
      "extraFieldsLeft": [
        ${"def.cnboxTierLeft"},
        ${"def.cnboxNameLeft"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        //${"def.xmqpServiceMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
      	//3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "286", "alpha": "{{alive? 20|0}}"},
      	//3{"x": 0, "y":  19 , "bgColor": ${"def.c1"}, "height":  5 , "width": "{{hp-ratio:286}}", "alpha": "{{alive? 30|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerLeft"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtL.damageDealt"},
        {}
      ],
      "extraFieldsRight": [
        ${"def.cnboxNameRight"},
        ${"def.cnboxTierRight"},
        //${"def.clanIcon"},
        ${"def.xvmUserMarker"},
        ${"def.enemySpottedMarker"},
		//${"def.BotMarker"},
        //${"def.hpBarBg"},
        //${"def.hpBar"},
        //${"def.hp"},
      	//3{"x": 0, "y":  19 , "bgColor": "0xFFFFFF", "height":  5 , "width": "293", "alpha": "{{alive? 20|0}}"},
      	//3{"x": 0, "y":  19 , "bgColor": ${"def.c2"}, "height":  5 , "width": "{{hp-ratio:293}}", "alpha": "{{alive? 50|0}}"},
        //4{"x": 60, "y": 6, "align": "center", "valign": "top", "src": "xvm://res/icons/flags/{{flag|default}}.png", "alpha": "{{alive?100|30}}", "shadow": {} },
        //5${"def.FriendsMarkerRight"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealtBg"},
		//6${"../playersPanel/extraFieldsDmg.xc":"damageDealtR.damageDealt"},
        {}
      ]
    }
  }
}
